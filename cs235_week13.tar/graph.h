/***********************************************************************
 * Component:
 *    Week 12, Graph
 *    Brother JonesL, CS 235
 * Author:
 *    John Vehikite, Tiffany Gohnert
 * Summary:
 *    This class represents a Graph
 ************************************************************************/

#ifndef GRAPH_H
#define GRAPH_H
//#include <vector>
#include "vertex.h"
#include "set.h"

 /*****************************************************************
 * GRAPH
 * Create a Graph
 *****************************************************************/
 //template <class T>
class Graph
{
public:

	// non-default constructor
	Graph(int numBuckets)
	{
		//numElements = 0;
		//if (numBuckets >= 25)
		//	numBuckets /= 5;
		this->numBuckets = numBuckets;
		elements = new int*[numBuckets];

		for (int i = 0; i < numBuckets; i++)
		{
			elements[i] = new int[numBuckets];
			for (int j = 0; j < numBuckets; j++)
			{
				elements[i][j] = 0;
			}
		}

	}

	// copy constructor
	Graph(const Graph & rhs)
	{
		this->elements = rhs.elements;
		this->numBuckets = rhs.numBuckets;
		//this->numElements = rhs.numElements;
	}

	// destructor
	~Graph() { /*clear();*/ }

	// Returns the number of elements in the Graph
	int  size() const { return numBuckets; }   // BinaryNode class needs a size function

	// determine if the hash is empty
	//bool clear() const { return numElements == 0; }

	// clear all the contents of the hash
	void clear() {  }

	
	//add(): Add one or more edge to the Graph. There are two overloaded add() 
	//functions: the first taking two vertices representing the new edge; 
	//the second taking a vertex and a set of vertices.
	void add(LVertex & edge, Set<Vertex>& path) 
	{
		SetIterator <Vertex> it;
		for (it = path.begin(); it != path.end(); it++)
		{
			Vertex tempVert = *it;
			elements[edge.index()][tempVert.index()] = 1;
		}
	}
	void add(CVertex & edge, CVertex& path) 
	{
		elements[edge.index()][path.index()] = 1;
	}
	
	void add(LVertex & edge, LVertex& path) 
	{
		elements[edge.index()][path.index()] = 1;
	}
	
	void add(CourseVertex & edge, CourseVertex & path) 
	{
		elements[edge.index()][path.index()] = 1;
	}

	//isEdge(): This method takes two vertices as parameters.
	// It returns true if there is an edge connecting the first 
	//vertex to the second.
	bool isEdge(CVertex & edge, CVertex& path) 
	{
		return elements[edge.index()][path.index()] == 1;
	}


	// This method takes on vertex as a parameter and 
	//returns the set of vertices that share an edge with it.
	Set <Vertex> findEdges(CourseVertex vertex)
	{
		Set <Vertex> tempSet;
		tempSet.insert(elements[vertex.index()][1]);
		if (elements[vertex.index()][2])
			tempSet.insert(elements[vertex.index()][2]);
		return tempSet;
	}


	//  Two vertices are passed. These represent the start vertex 
	//and the end vertex. The return value will be a vector of all 
	//the vertices on the shortest path between the two.
	int findPath(int t)
	{
		return t;
	}



	// operator=: Assignment operator. Copy one Graph into another. 
	// If there is insufficient memory to allocate a new buffer, then 
	// the following exception is thrown:
	// ERROR: Unable to allocate memory for the hash.
	Graph  & operator = (const Graph  & rhs)
	{
		this->elements = rhs.elements;
		this->numBuckets = rhs.numBuckets;
		//this->numElements = rhs.numElements;
		return *this;
	}



private:

	// member variables
	// vector < vector <int> > elements;
	int ** elements;
	//int numElements; // size()
	int numBuckets; // capacity()
};


#endif // GRAPH_H