﻿#ifndef  SET_H
#define SET_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <algorithm> // sort; binary_search
#include <stdio.h>
using namespace std;


// forward declaration for SetIterator
template <class T>
class SetIterator;

// forward declaration for SetIterator
template <class T>
class SetConstIterator;

//set class
template <class T>
class Set
{

  public:

   //default constructor
  Set():  Size(0),Capacity(0), vector(0x00000000){}

   //destructor
   ~Set(){};
   // { if (Size) delete [] vector; }

   //non-default constructor 
   Set(int capacity) throw (const char *);

   //copy constructor
   Set(const Set& rhs)throw (const char *);


   // assignment operator
   Set & operator = (const Set & rhs) throw (const char *)
   {
           try
           {  
			   //Set temp = rhs;
			   Capacity = rhs.Capacity;
			   vector = rhs.vector;
			   Size = rhs.Size;
			   return *this;
           }
           catch (std::bad_alloc)
           {
              throw "ERROR: Unable to allocate a new buffer for Set";
           }

   }

   //empty()
   bool empty() const { return Size == 0; }

   //size()
   int size()const { return Size; }

   //capacity()
   int capacity()const { return Capacity; }

   //clear()
   void clear() { Size = 0; }

   int clear() const { Size =0; return Size; } 

   // return an iterator to the beginning of the list
   SetIterator <T> begin() { return SetIterator<T>(vector); }
   
   SetConstIterator <T> cbegin() const { return SetConstIterator <T>(vector); }

   // return an iterator to the end of the list
   SetIterator <T> end() { return SetIterator<T>(vector + Size); }

   SetConstIterator <T> cend() const { return SetConstIterator <T>(vector + Size); }

   SetIterator <T> find(const T & t)
   {
	   /*
	   find(): Takes a template item as a 
	   parameter and returns an iterator 
	   pointing to the corresponding item in 
	   the set. If the item does not exist, 
	   it returns Set::end(). Note that the 
	   pseudocode in the reading returns an 
	   index so some modification to that 
	   pseudocode will be required.
	   */

	   /*
	   find (element)
		iBegin = 0
		iEnd = numElements – 1
		WHILE iBegin ≤ iEnd
			iMiddle = (iBegin + iEnd) / 2
			IF element = array[iMiddle]
				RETURN iMiddle
			IF element < array[iMiddle]
				iEnd = iMiddle – 1
			ELSE
				iBegin = iMiddle + 1
		RETURN numElements
	   */
	  // Unsorted
	   SetIterator <T> it;
	   for (it = begin(); it != end(); it++)
	   {
		   if (t == *it)

			   return it;
			 		   
	   }
	 
	   return it;
	   
   }

   void insert(const T & t)
   {
	   /*
	   insert(): Add an item to the set. This method
	   has a void return type. One parameter will be
	   expected, the item to be added to the set. Note
	   that the order in the set must be preserved. This
	   means that the correct location in the set must
	   be found before insertion. Also, if the item
	   already exists in the set, then nothing is done.
	   Of course, if the capacity is insufficient to hold
	   the newly inserted item, then it will need to double
	   the buffer size just like Container.
	   */

	   /*
	   insert(element)
		iInsert = find(element)
		if array[iInsert] ≠ element
			FOR i = numElements … iInsert by -1’s
				array[i + 1] = array[i]
			array[iInsert] = element
			num_elements++
	   */
	   
	   if (this->Capacity == 0)
	   {
		   delete[] vector;
		   Capacity = 1;
		   this->vector = new T[Capacity];

		   //this->vector=vector; 
		   this->Capacity = 1;
		   this->Size = 0;
	   }

	   // Sorted
	   /*SetIterator <T> it;
	   SetIterator <T> iInsert = find(t);
	   if (*iInsert != t)
	   {
		   for (it = this->end(); iInsert !=begin(); iInsert--)
		   {
			   
		   }
	   }*/

	 

	   if (Capacity == Size)
	   {
		   try
		   {
			   Capacity *= 2;
			   T * tempArray = new T[Capacity];
			   for (int i = 0; i < this->Size; i++)
			   {
				   tempArray[i] = this->vector[i];
			   }
			   delete[] this->vector;
			   this->vector = tempArray;


		   }
		   catch (std::bad_alloc)
		   {
			   throw "ERROR: Unable to allocate a new buffer for Set";
		   }
	   }
	     // Unsorted
	 

	 SetIterator <T> it;
	   SetIterator <T> itEnd;
	   
	  
	   for (it =begin(); it != end(); it++)
	   {
		   if (t == *it)
			   return;
			   
	   }
	   
	   Size++;	   
	   vector[Size - 1] = t;
	  sort(vector, vector + Size);
	
	   

   }

   void erase(SetIterator <T> it)
   {
	   /*
	   erase(): Remove an element from the set. This method 
	   takes an iterator as a parameter, referring to the 
	   element to be removed from the set. Note that the 
	   pseudocode in the reading takes an index so some 
	   modification to that pseudocode will be required. 
	   There is no return value.
	   */

	   /*
	   delete(element)
			iDelete= find(element)
			if array[iDelete] = element
				FOR i = iDelete … numElements
					array[i] = array[I + 1]
			numElements--
	   */
	   

	   // Unsorted
	   for (int i = 0; i < Size; i++)
	   {
		   if (vector[i] == (*it))
		   {
			   vector[i] = vector[--Size];
			   break;
		   }
	   }

	   // Sort vector
	   sort(vector, vector + Size);
   }

   Set operator && (Set s)
   {
	   /*
	   operator&&(): The intersection operator. The parameter 
	   is a Set object and the return value is a new Set object 
	   containing all the elements that are in both this and 
	   in the parameter.
	   */

	   /*
	   union(set1, set2)
		iSet1 = 0
		iSet2 = 0
		WHILE iSet1 < set1.numElements OR iSet2 < set2.numElements
			IF iSet1 == set1.numElements
				setReturn.addToEnd(set2.array[iSet2++])
			ELSE IF iSet2 == set2.num_elements
				setReturn.addToEnd(set1.array[iSet1++])
			ELSE IF set1.array[iSet1] == set2.array[iSet2]
				setReturn.addToEnd(set1.array[iSet1])
				iSet1++
				iSet2++
			ELSE IF set1.array[iSet1] < set1.array[iSet2]
				setReturn.addToEnd(set1.array[iSet1++])
			ELSE
				setReturn.addToEnd(set2.array[iSet2++])
		RETURN setReturn
	   */

	   // unsorted
	   /*Set setReturn = *this;
	   SetIterator <T> it;
	   for (it = s.begin(); it != s.end(); it++)
	   {
		   setReturn.insert(*it);
	   }
	   return setReturn;*/
	   Set setReturn;
	   SetIterator <T> it;
	   for (it = this->begin(); it != this->end(); it++)
	   {
		   if (s.find(*it) != s.end())
			   setReturn.insert(*it);
	   }
	   return setReturn;


   }

   Set operator || (const Set s)
   {
	   /*
	   operator||(): The union operator. The parameter is a 
	   Set object and the return value is a new Set object 
	   containing all the elements that are in either this or 
	   in the parameter.
	   */

	   /*
	   intersection(set1, set2)
		iSet1 = 0
		iSet2 = 0
		WHILE iSet1 < set1.numElements OR iSet2 < set2.numElements
			IF iSet1 == set1.numElements
				RETURN setReturn
			ELSE IF iSet2 == set2.num_elements
				RETURN setReturn
			ELSE IF set1.array[iSet1] == set2.array[iSet2]
				setReturn.addToEnd(set1.array[iSet1])
				iSet1++
				iSet2++
			ELSE IF set1.array[iSet1] < set1.array[iSet2]
				iSet1++
			ELSE
				iSet2++
		RETURN setReturn

	   */

	   //unsorted
	   Set setReturn = s;
	   SetIterator <T> it;
	   for (it = begin(); it != end(); it++)
	   {
	    
		   setReturn.insert(*it);
	   }
	  
	   return setReturn;
   }
   
    Set operator - (Set s)
   {
	   Set setReturn;
	   SetIterator <T> it;
	   for (it = this->begin(); it != this->end(); it++)
	   {
		   if (s.find(*it) != s.end())
			     continue;
		   if (setReturn.size() > 0)
		   {
			   if (setReturn.find(*it) != setReturn.end())
				   continue;
		   }
		   setReturn.insert(*it);
	   }
	   return setReturn;
   }


   
  private:

   int Size;
   T * vector;
   int Capacity;
};

/**************************************************
* SET ITERATOR
* An iterator through Set
*************************************************/
template <class T>
class SetIterator
{
public:
	// default constructor
	SetIterator() : p(NULL) {}

	// initialize to direct p to some item
	SetIterator(T * p) : p(p) {}

	// copy constructor
	SetIterator(const SetIterator & rhs) { *this = rhs; }

	// assignment operator
	SetIterator & operator = (const SetIterator & rhs)
	{
		this->p = rhs.p;
		return *this;
	}

	// not equals operator
	bool operator == (const SetIterator & rhs) const
	{
		return rhs.p == this->p;
	}

	// not equals operator
	bool operator != (const SetIterator & rhs) const
	{
		return rhs.p != this->p;
	}

	// dereference operator
	T & operator * ()
	{
		return *p;
	}

	// prefix increment
	SetIterator <T> & operator ++ ()
	{
		p++;
		return *this;
	}

	// postfix increment
	SetIterator <T> operator++(int postfix)
	{
		SetIterator tmp(*this);
		p++;
		return tmp;
	}

	// prefix decrement
	SetIterator <T> & operator -- ()
	{
		p--;
		return *this;
	}

	// postfix increment
	SetIterator <T> operator--(int postfix)
	{
		SetIterator tmp(*this);
		p--;
		return tmp;
	}

private:
	T * p;
};

/**************************************************
* SET CONST ITERATOR
* A const iterator through Set
*************************************************/
template <class T>
class SetConstIterator
{
public:
	// default constructor
	SetConstIterator() : p(NULL) {}

	// initialize to direct p to some item
	SetConstIterator(T * p) : p(p) {}

	// copy constructor
	SetConstIterator(const SetConstIterator & rhs) { *this = rhs; }

	// assignment operator
	SetConstIterator & operator = (const SetConstIterator & rhs)
	{
		this->p = rhs.p;
		return *this;
	}

	// not equals operator
	bool operator == (const SetConstIterator & rhs) const
	{
		return rhs.p == this->p;
	}

	// not equals operator
	bool operator != (const SetConstIterator & rhs) const
	{
		return rhs.p != this->p;
	}

	// dereference operator
	T & operator * ()
	{
		return *p;
	}

	// prefix increment
	SetConstIterator <T> & operator ++ ()
	{
		p++;
		return *this;
	}

	// postfix increment
	SetConstIterator <T> operator++(int postfix)
	{
		SetConstIterator tmp(*this);
		p++;
		return tmp;
	}

	// prefix decrement
	SetConstIterator <T> & operator -- ()
	{
		p--;
		return *this;
	}

	// postfix increment
	SetConstIterator <T> operator--(int postfix)
	{
		SetConstIterator tmp(*this);
		p--;
		return tmp;
	}

private:
	T * p;
};

/**********************************************
 * Set : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Set to "capacity"
 **********************************************/
template <class T>
Set <T> :: Set(int capacity) throw (const char *)
{
   assert(capacity >= 0);

   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->Capacity = this->Size = 0;
      this->vector = 0x00000000;
	  return;
   }

   // attempt to allocate
            try
            {
               vector = new T[capacity];

            }
            catch (std::bad_alloc)
            {
               //problem for test 1
               throw "ERROR: Unable to allocate buffer";


            }


            // copy over the stuff
            this->Capacity = capacity;
            this->Size = 0;
}

/*******************************************
 * Set:: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Set <T> :: Set(const Set <T> & rhs) throw (const char *)
{

   assert(rhs.Capacity >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.Capacity == 0)
   {
      Capacity = Size=0;
      vector = 0x00000000;
      return;
   }

   // attempt to allocate
   try
   {
      vector = new T[rhs.Capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
   
   // copy over the stuff
   assert(rhs.Size >= 0 && rhs.Size <= rhs.Capacity);
   Capacity = rhs.Capacity;
   Size = rhs.Size;
   for (int i = 0; i < Size; i++)
      vector[i] = rhs.vector[i];
   
   
   
}


#endif
