#ifndef  QUEUE_H
#define QUEUE_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <stack>
using namespace std;


//stack class
template <class T>
class Queue
{

  public:

   //default constructor
  Queue():  Size(0),Capacity(0), vector(0x00000000), myFront(-1), myBack(-1){}

   //destructor
   ~Queue(){};
   // { if (Size) delete [] vector; }

   //non-default constructor Needed for test 1
   Queue(int capacity) throw (const char *);

   //copy constructor
   Queue(const Queue& rhs)throw (const char *);


   // assignment operator
   Queue & operator = (const Queue & rhs)throw (const char *)
   {
           try
           {  Queue temp = rhs;
              Capacity = temp.Capacity;
              vector = temp.vector;
              Size = temp.Size;
			  myFront = temp.myFront; 
			  myBack = temp.myBack; 
              return *this;
           }
           catch (std::bad_alloc)
           {
              throw "ERROR: Unable to allocate a new buffer for Queue";
           }

   }

   //empty()
   bool empty()const {return Size ==0;  }
   //clear()
   void clear(){Size =0; }

   //size()
   int size()const{return Size; }
   //capacity()
   int capacity()const {   return Capacity;}
   
   int clear() const {Size =0; return Size; }; 

   //push_back
   void push(const T & t) throw (const char *);
   void pop() throw (const char *);
    T front() throw (const char *); 
	 T back() throw (const char *); 
   

   // return an iterator to the beginning of the list
   //QueueIterator <T> begin() { return QueueIterator<T>(vector); }

   // return an iterator to the end of the list
   // QueueIterator <T> end() { return QueueIterator<T>(vector + Size);};



   // operators[]
   T & operator [](int& index) const throw(const char *)
   {
      if (Capacity < 0 || Capacity < Size)
         throw "ERROR: Invalid index\n";
      return vector[index];
   }

   T & operator [](int& index) throw(const char *)
   {
      if (Capacity < 0 || Capacity < Size)
         throw "ERROR: Invalid index\n";
      return vector[index];
   }




  private:

   int Size;
   T * vector;
   int Capacity;
   int myFront; 
   int myBack; 
  


};

/**********************************************
 * Queue : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Queue to "capacity"
 **********************************************/
template <class T>
Queue <T> :: Queue(int capacity) throw (const char *)
{
   assert(capacity >= 0);

   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->Capacity = this->Size = 0;
      this->vector = 0x00000000;
	  this->myFront= 0; 
	  this->myBack=0; 
      return;
   }

   // attempt to allocate
            try
            {
               vector = new T[capacity];

            }
            catch (std::bad_alloc)
            {
               //problem for test 1
               throw "ERROR: Unable to allocate buffer";


            }


            // copy over the stuff
            this->Capacity = capacity;
            this->Size = 0;
			this->myBack=0; 
			this->myFront=0; 

}

/*******************************************
 * Queue:: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Queue <T> :: Queue(const Queue <T> & rhs) throw (const char *)
{
   assert(rhs.Capacity >= 0);

   // do nothing if there is nothing to do
   if (rhs.Capacity == 0)
   {
      Capacity = Size = 0;
      vector = 0x00000000;
	  myFront=myBack=0; //sets capacity to 1; 
      return;
   }

   // attempt to allocate
          try
          {
             vector = new T[rhs.Capacity];
          }
          catch (std::bad_alloc)
          {
             throw "ERROR: Unable to allocate buffer";
          }

          // copy over the stuff
          assert(rhs.Size >= 0 && rhs.Size <= rhs.Capacity);
          this->Capacity = rhs.Capacity;
          this->Size = rhs.Size;
		  this->myFront = rhs.myFront; 
		  this->myBack = rhs.myBack;  
       // for (int i = myFront; i < Size; i++)
           // vector[i] = rhs.vector[i];
			//for (int i = 0; i < Size; i++)
         // vector[i] = rhs.vector[i];
		 
		 if ((myFront==0) && (myBack > myFront) && (myBack <= Capacity))
		  {
		  for(int i=myFront; i <myBack; i++)
		  vector[i]=rhs.vector[i];
		  if (myBack +1 <Capacity)
		  {
		  for (int i=myBack; i <Capacity; i++)
		  vector[i] = T(); 
		  }
		  }
		  
		  else if ((myFront>0) && (myBack >myFront)&& (myBack <=Capacity))
		  {
		  for (int i =myFront; i<myBack; i++)
		  vector[i]=rhs.vector[i]; 
		  if (myBack +1 < Capacity)
		  {
		  for (int i = myBack; i < Capacity; i++)
		  vector[i] = T(); 
		  for (int i=0; i<myFront; i++)
		  vector[i] = T();
		  }
		  }
		  
		   else if ((myFront>0) && (myBack <myFront)&& (myFront <=Capacity))
		  {
		  for (int i =myFront; i<Capacity; i++)
		  vector[i]=rhs.vector[i]; 
		  
		  for (int i = 0; i < myBack; i++)
		  vector[i] = rhs.vector[i]; 
		  for (int i=myBack; i<myFront; i++)
		  vector[i] = T();
		  }
		  
		  
		  else if (empty() && Capacity >0)
		  {
		  for (int i=0; i<Capacity; i++)
		  vector[i]=T(); 
		  }
		 
}

/***************************************************
 * Queue :: push
 * Insert an item on the end of the Queue
 **************************************************/
template <class T>
void Queue <T> :: push(const T & t) throw (const char *)
{

	if (this->Capacity == 0)
	{
		delete[] vector;
		Capacity = 1;
		this->vector = new T[Capacity];
		
		//this->vector=vector; 
		this->Capacity=1; 
		this->myFront=0; 
		this->myBack=0; 
		this->Size=0; 
	}
	 /*if (Capacity == Size)
	{
try
{
		Capacity *= 2;
		T * tempArray = new T[Capacity];
		for (int i = 0; i < this->Size; i++)
		{	tempArray[i] = this->vector[i];}
		delete[] this->vector;
		this->vector = tempArray;
	
	
	}
	catch (std::bad_alloc)
	{
		throw "ERROR: Unable to allocate a new buffer for Vector";
	}
	
	
	
}*/


if(myBack==Capacity)
myBack=0; 
this->vector[myBack]=t; 
myBack++; 
Size++; 

//if (Capacity == Size)
//{
//	try
//	{
//		Capacity *= 2;
//		T * tempArray = new T[Capacity];
//		for (int i = 0; i < this->Size; i++)
//		{
//			tempArray[i] = this->vector[i];
//		}
//		delete[] this->vector;
//		this->vector = tempArray;
//
//
//	}
//	catch (std::bad_alloc)
//	{
//		throw "ERROR: Unable to allocate a new buffer for Vector";
//	}
//
//
//
//}

if (Capacity == Size)
{
	try
	{
		Capacity *= 2;
		T * tempArray = new T[Capacity];
		for (int i = 0; i < this->Size; i++)
		{
			tempArray[i] = this->vector[i];
		}
		delete[] this->vector;
		this->vector = tempArray;


	}
	catch (std::bad_alloc)
	{
		throw "ERROR: Unable to allocate a new buffer for Vector";
	}



}

}
//pop()
/***************************************************
 * Queue :: pop
 * Removes an item from the end of the stack
 **************************************************/
template <class T>
 void Queue <T> :: pop() throw (const char *)
{
	if (empty())
		throw "ERROR: attempting to pop from an empty queue";
	else
	{
	myFront=(myFront + 1) % Capacity;
	Size--; 
	//vector[myFront];
	
	//if(myFront==Capacity)
	//{
	//myFront=0; //problem here. 
	//}
	//else
	//myFront++; 
	//Size--; 
	}
}



/***************************************************
 * Queue :: front
 * Returns the item currently at the end of the stack
 **************************************************/
template <class T>
T Queue <T> :: front() throw (const char *)
{
	if (empty())
		throw "ERROR: attempting to access an item in an empty queue";
	return vector[myFront];   
}

/***************************************************
 * Queue :: back
 * Returns the item currently at the end of the stack
 **************************************************/
template <class T>
T Queue <T> :: back() throw (const char *)
{
	if (empty())
		throw "ERROR: attempting to access an item in an empty queue";
		//myBack = (myBack-1)%Capacity; 
	return vector[Size];   
}


 

#endif
