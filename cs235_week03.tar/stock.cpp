/***********************************************************************
 * Implementation:
 *    STOCK
 * Summary:
 *    This will contain the implementation for stocksBuySell() as well
 *    as any other function or class implementation you need
 * Author
 *    <your names here>
 **********************************************************************/

#include <iostream>    // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include "stock.h"     // for STOCK_TRANSACTION
#include "queue.h"     // for QUEUE
#include <sstream>     // for ISTRINGSTREAM
#include <cstdlib>
using namespace std;

/************************************************
 * STOCKS BUY SELL
 * The interactive function allowing the user to
 * buy and sell stocks
 ***********************************************/
void stocksBuySell()
{
	// instructions
	cout << "This program will allow you to buy and sell stocks. "
		<< "The actions are:\n";
	cout << "  buy 200 $1.57   - Buy 200 shares at $1.57\n";
	cout << "  sell 150 $2.15  - Sell 150 shares at $2.15\n";
	cout << "  display         - Display your current stock portfolio\n";
	cout << "  quit            - Display a final report and quit the program\n";

	// your code here...
	Queue <int> shares;
	Queue <Dollars> prices;
	Queue <int> soldShares;
	Queue <Dollars> sales;
	string input;
	int share;
	Dollars price, proceeds = 0;
	
	do
	{
		//prompt user for input
		cout << "> ";
		cin >> input;
		if (input == "buy")
		{
			cin >> share >> price;
			shares.push(share);
			prices.push(price);
		}

		if (input == "sell")
		{
			assert(!shares.empty());
			cin >> share >> price;
			soldShares.push(share);
			sales.push(price);
			
		}

		if (input == "display")
		{
			Queue <int> copyShares(shares);
			Queue <Dollars> copyPrices(prices);
			cout << "Currently held:\n";
			while (!copyShares.empty())
			{
				cout << "\tBought " << copyShares.front()
					<< " shares at " << copyPrices.front() << endl;
				copyShares.pop();
				copyPrices.pop();
				//cout << "Proceeds: " << proceeds;
			}
		}

		if (input == "quit")
			exit(-1);
	} while (input != "quit");
}
// try{
// 
// do
//   {
//      // handle errors
//      if (cin.fail())
//      {
//         cin.clear();
//         cin.ignore(256, '\n');
//      }
//      
//      // prompt for infix
//       cout << "> ";
// 
//      getline(cin, choice);
//
//	  // push into buy array
//	    if (choice == "buy")
//      {
//	  
//	   while (i < choice.length()) {
//      buy = choice[i];
//	  q.push(buy);
//         i++;
//         continue;
//		 }
//      }
//	  //push into sell array
//	    if (choice == "sell")
//      {
//	 /*
//	 When selling shares, use the oldest transactions first. 
//	 This may mean one of three things: 1) only part of a 
//	 buy-batch is used, 2) a complete buy-batch is used, 
//	 or 3) multiple buy-batches are required to cover a given 
//	 stock sell. Your program should handle all three cases.
//	 */
//
//	 //  while (i < choice.length()) {
//      //sell = choice[i];
//	 // q.push(sell);
//     //    i++;
//     //    continue;
//	//	 }
//      }
//	  
//	  
//		/*
//		Compute the profit from a given sell buy subtracting the 
//		sell price from the buy price, multiplying the result by 
//		the number of shares sold. The proceeds are the sum of all 
//		the stock sells in the history.
//		*/
//      // generate display
//      if (choice == "display")
//      {
//		  /*
//		  Only display "Currently held:" and "Sell History:" 
//		  if there are transactions to display.
//		  */
//         //string postfix = convertInfixToPostfix(input);
//         cout << "Currently held:\n"; 
//		 //return all bought
////cout << "\tBought " <<buy[0] <<" shares at " <<buy[1] << endl; 
// q.pop();
//               break;
//      }
//	  
//	
//	  
//	  
//   }
//   while (choice != "quit");
//   }
//   catch (const char * error)
//   {
//      cout << error << endl;
//   }
//   
//   if (choice == "quit")
//   {
//   exit(-1); 
//   }
//}