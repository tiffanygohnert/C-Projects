#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <string>
 
using namespace std;
 
class WordCounter
{
public:
    double value;
    WordCounter() : value( 0 ) {}
     
    void operator++ (int) { value++; }
};
 
 
ostream& operator<<(ostream& st, WordCounter& wc )
{
    return st << wc.value;
}
 
string path ;
 
void wordCount()
{
//variables
    map<string, WordCounter> counter; 
    ifstream input;
	string tok;  
	
	//prompt for file
cout << "What is the filename to be counted?"; 
cin >> path; 
	
	//open
    input.open( path.c_str() );
 
 //if can't open error
    if ( !input )
    {
        cout << "Error in opening file.\n";
        return;
    }
 
    

//get word 
cout << "What word whose frequency is to be found. Type ! when done\n"; 

//put in loop
do
{
 
cout << ">"; 
cin >> tok; 

	//count
    while ( true )
    {
        input >> tok;
         
        if ( input )
        {
            counter[ tok ]++;
        }
        else break;     
    }
 
  
 //output 
	cout <<"\t"
			<< tok
             << " : "
             << counter[tok]
             << endl;
	
	
	}
	while (tok != "!");
 
    return;
}