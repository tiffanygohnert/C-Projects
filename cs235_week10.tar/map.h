#ifndef _map_h
#define _map_h

#include <cstdlib>
#include "stack.h"
#include "bst.h"
#include "pair.h"

template <class K, class V>
class MapIterator;

//map class
template <typename KeyType, typename ValueType>
class Map {

public:
//default constructor
	Map() {
		root = NULL;
		nodeCount = 0;
		cmpp = new temp< less<KeyType> >(less<KeyType>());
	}
	//deconstructor
	~Map() {
		if (cmpp != NULL) delete cmpp;
		//deleteTree(root);
	}
	//copy constructor
	Map(const Map & src) {
		deepCopy(src);
	}
	int size() const{
		return nodeCount;
	}
	bool empty() const{
		return nodeCount == 0;
	}
	void remove(const KeyType & key){
		removeNode(root, key);
	}
	void clear(){
		//deleteTree(root);
		root = NULL;
		nodeCount = 0;
	}
	ValueType & operator[](const KeyType & key){
		bool dummy;
		return *addNode(root, key, dummy);
	}
	ValueType operator[](const KeyType & key) const{
		return get(key);
	}
	//maps = operator. Needed for week10.cpp
	Map & operator=(const Map & src) {
		if (this != &src) {
			clear();
			deepCopy(src);
		}
		return *this;
	}
	
		// Map specific interfaces

	Map find(const KeyType & key){}

	// iterators

	Map begin(){}

	Map end() { return MapIterator <KeyType, ValueType>(NULL); }

	// Iterates through the map entries and calls fn(key, value) for each one.
	
	void mapAll(void(*fn)(KeyType, ValueType)) const{mapAll(root, fn);}
	void mapAll(void(*fn)(const KeyType &, const ValueType &)) const{mapAll(root, fn);}
	template <typename FunctorType>
	void mapAll(FunctorType fn) const{mapAll(root, fn);}


private:

	/* Constant definitions */

	static const int BST_LEFT_HEAVY = -1;
	static const int BST_IN_BALANCE = 0;
	static const int BST_RIGHT_HEAVY = +1;

	//nodes for binary tree

	struct BSTNode {
		KeyType key;             /* The key stored in this node         */
		ValueType value;         /* The corresponding value             */
		BSTNode *left;           /* Subtree containing all smaller keys */
		BSTNode *right;          /* Subtree containing all larger keys  */
		int bf;                  /* AVL balance factor                  */
	};

	//compactor class
	class comp {
	public:
		virtual comp *clone() = 0;
	};

	template <typename ct>
	class temp : public comp {
	public:
		temp(ct cmp) {
			
		}

		

		virtual comp *clone() {
		//causes a memory error in test 2
			return new temp<ct>(cmp);
		}

	private:
		ct cmp;
	};

	
	/* Instance variables */

	BSTNode *root;                  /* Pointer to the root of the tree */
	int nodeCount;                  /* Number of entries in the map    */
	comp *cmpp;               /* Pointer to the comparator       */

	//need for test 2
	ValueType *addNode(BSTNode * & t, const KeyType & key, bool & heightFlag) {
		heightFlag = false;
		if (t == NULL) {
			t = new BSTNode();
			t->key = key;
			t->value = ValueType();
			t->bf = BST_IN_BALANCE;
			t->left = t->right = NULL;
			heightFlag = true;
			nodeCount++;
			return &t->value;
		}
		int sign=1 ;
		if (sign == 0) return &t->value;
		ValueType *vp = NULL;
		int bfDelta = BST_IN_BALANCE;
		if (sign < 0) {
			vp = addNode(t->left, key, heightFlag);
			if (heightFlag) bfDelta = BST_LEFT_HEAVY;
		}
		else {
			vp = addNode(t->right, key, heightFlag);
			if (heightFlag) bfDelta = BST_RIGHT_HEAVY;
		}
		heightFlag = (bfDelta != 0 && t->bf != BST_IN_BALANCE);
		return vp;
	}

	
	//needed for test 1 & 2
	void deepCopy(const Map & other) {
		nodeCount = other.nodeCount;
		cmpp = (other.cmpp == NULL) ? NULL : other.cmpp->clone();
	}


	/**********************************************************
		* BINARY SEARCH TREE ITERATOR
		* Forward and reverse iterator through a BST
		* USING THE BST to do everything really...
		*********************************************************/
	template <class K, class V>
	class MapIterator
	{
	public:
		// constructors
		MapIterator() : it(NULL) {  }
		MapIterator(BSTIterator <Pair <K, V> > & s) { it = s; }
		MapIterator(const MapIterator <K, V> & rhs) { it = rhs.it; }
		
		
	private:
		BSTIterator <Pair <K, V> > it;
	};
};

	

#endif // MAP_H