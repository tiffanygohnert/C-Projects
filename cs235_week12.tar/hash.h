/***********************************************************************
 * Component:
 *    Week 11, Hash
 *    Brother JonesL, CS 235
 * Author:
 *    John Vehikite, Tiffany Gohnert
 * Summary:
 *    This class represents a Hash.
 ************************************************************************/

#ifndef HASH_H
#define HASH_H

#include "list.h" // for List


 // forward declaration for the BST iterator
template <class T>
class Hash;

/*****************************************************************
* HASH
* Create a Hash
*****************************************************************/
template <class T>
class Hash
{
public:

	// non-default constructor
	Hash(int numBuckets) 
	{
		numElements = 0;
		this->numBuckets = numBuckets;
		linkedList = new List <T> [numBuckets];
	}

	// copy constructor
	Hash(const Hash & rhs) 
	{
		this->linkedList = rhs.linkedList;
		this->numBuckets = rhs.numBuckets;
		this->numElements = rhs.numElements;
	}

	// destructor
	~Hash() { /*clear();*/ }

	// Returns the number of elements in the Hash
	int  size() const { return numElements; }   // BinaryNode class needs a size function

	// determine if the hash is empty
	bool empty() const { return numElements == 0; }

	// capacity(): Returns the number of buckets in the Hash
	int capacity()const { return numBuckets; }

	// clear all the contents of the hash
	// void clear() { delete linkedList; }

	// find(): The parameter is the value to be found. Returns 
	// true if the value is found, false otherwise.
	bool find(T & t)
	{
		for (int i = 0; i < numBuckets; i++)
		{
			if (linkedList[i].size() == 0)
				continue;
			T temp = linkedList[i].front();
			if (temp == t)
				return true;
		}
		return false;
	}


	// operator=: Assignment operator. Copy one Hash into another. 
	// If there is insufficient memory to allocate a new buffer, then 
	// the following exception is thrown:
	// ERROR: Unable to allocate memory for the hash.
	Hash <T> & operator = (const Hash <T> & rhs)
	{
		this->linkedList = rhs.linkedList;
		this->numBuckets = rhs.numBuckets;
		this->numElements = rhs.numElements;
		return *this;
	}

	// insert(): Places a new instance of a value in the Hash. The 
	// parameter is the item to be inserted; there is no return value.
	void insert(const T & t)
	{
		int index = hash(t);
		/*List <T> tempList = linkedList[index];
		tempList.push_back(t);
		linkedList[index] = tempList;*/
		linkedList[index].push_back(t);
		numElements++;
	}

	// hash(): This is a pure virtual function taking an element as a 
	// parameter and returning an index into the underlying array
	virtual int hash(const T & t) const = 0;

private:

	// member variables
	List <T> * linkedList;
	int numElements; // size()
	int numBuckets; // capacity()
};

//template <class T>
//Hash <T> & Hash <T> :: operator = (const Hash <T> & rhs)
//{
//	this->linkedList = rhs.linkedList;
//	this->numBuckets = rhs.numBuckets;
//	this->numElements = rhs.numElements;
//}

#endif // HASH_H