/***********************************************************************
 * Module:
 *    Week 12, Spell Check
 *    Brother Helfrich, CS 235
 * Author:
 *    John Vehikite, Tiffany Gohnert
 * Summary:
 *    This program will implement the spellCheck() function
 ************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <algorithm>    // std::remove_if
#include "spellCheck.h"
#include "hash.h"
using namespace std;


/****************************************
 * F HASH
 * A hash string
 ****************************************/
class FHash : public Hash <string>
{
public:
   FHash(int numBuckets, float min, float max) throw (const char *) :
         Hash <string> (numBuckets), min(min), max(max)  {}
   FHash(const FHash & rhs) throw (const char *) :
         Hash <string> (rhs), min(rhs.min), max(rhs.max) {}

   // hash function for strings will add up all the ASCII values
   int hash(const string & value) const
   {
	   return 0;
   }
private:
   float min;
   float max;
};




void upToLow(string & str);
void removePunct(string & str);

/*****************************************
 * SPELL CHECK
 * Prompt the user for a file to spell-check
 ****************************************/

 void spellCheck()
{
FHash h(10 /*capacity*/, 1.0 /*min*/, 10.0 /*max*/);
//Hash <string> h; 
	string currWord;
	string word;
	int countMisspelled = 0;
	int countCorrect = 0;

	//Get input from the dictionary
	ifstream dictionary("dictionary.txt");

	//File checking
	if (dictionary.fail())
	{
		cout << "File does not exist" << endl;
		cout << "Exit program" << endl;
	}

    //Create the dictionary as a hash table
    while(dictionary >> currWord)
    {
    	h.insert(currWord);
    }
    dictionary.close();

    //Get input from the user
    ifstream input;
	string fileName; 
	
	//prompt user
	cout <<  "What file do you want to check?" << endl; 
	cin >> fileName; 

	//open the file
	input.open(fileName.c_str()); 

	//File checking
	if (input.fail())
	{
		cout << "Error opening file" << endl;
	}


	//If a word is not in the dictionary assume misspelled
	while(input >> word)
	{
		removePunct(word);
		upToLow(word);
		
		
		//if it can't find the word in the dictionary then it's misspelled
		//find?
		
		if (h.find(word) ==false)
		
		{
		
		countMisspelled++; // Increment misspelled words count
			
		}
		else
		{
			countCorrect++; // Increment correct words count
		}
	}
	input.close();

	if (countMisspelled >= 1)
	{
	cout << "Number of misspelled words : " << countMisspelled << endl;}
	else
	{cout << "File contains no spelling errors" << countCorrect << endl;}

	
}


/*Function to convert uppercase letters to lowercase*/
void upToLow(string & str)
{
	for (unsigned int i = 0; i < strlen(str.c_str()); i++)
		 if (str[i] >= 0x41 && str[i] <= 0x5A)
			  str[i] = str[i] + 0x20;
}


/*Function to remove punctuation from string*/
void removePunct(string & str)
{
	str.erase(remove_if(str.begin(), str.end(), static_cast<int(*)(int)>(&ispunct)),str.end());
}
