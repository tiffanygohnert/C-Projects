/***********************************************************************
 * Header:
 *    FIBONACCI
 * Summary:
 *    This will contain just the prototype for fibonacci(). You may
 *    want to put other class definitions here as well.
 * Author
 *    Tiffany Gohnert, John Vehikite
 ************************************************************************/

#ifndef FIBONACCI_H
#define FIBONACCI_H
#include <iostream>
using namespace std;




// the interactive fibonacci program
void fibonacci();
int Number(int number);




#endif // FIBONACCI_H

