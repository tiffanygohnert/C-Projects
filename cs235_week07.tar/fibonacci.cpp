/***********************************************************************
 * Implementation:
 *    FIBONACCI
 * Summary:
 *    This will contain the implementation for fibonacci() as well as any
 *    other function or class implementations you may need
 * Author
 *    Tiffany Gohnert, John Vehikite
 **********************************************************************/

#include <iostream>
#include "fibonacci.h"   // for fibonacci() prototype
#include "list.h"        // for LIST
#include <list>
using namespace std;


class Big
{
   private:
   //problem? 
      List<int> chunks;
       int chunkSize;
	  
	  
      
	   
   public:
     
   //default constructor sets chuckSize
	  Big() : chunkSize(1000000000) {}
      
	 // non-default constructor taking an unsigned int as a parameter
	 Big(unsigned int data)
{
//reset chuckSize
   chunkSize = 1000000000;
   
   
   //problem here
   //inset data into list
    ListIterator <int> it;
   
               it = chunks.begin();
               while (chunkSize-- > 0)
                  ++it;
              
      
  chunks.insert(it,data);
   
   
  
}
     

//copy constructor
	Big(const Big & rightSide)
{
   chunkSize = rightSide.chunkSize;
   //with or without the List<int>?
   chunks = List<int>(rightSide.chunks);
}
	  
  //operators
      Big & operator = (Big rightSide){
   chunks = rightSide.chunks;
   chunkSize = rightSide.chunkSize;
   return (*this);
}
      Big operator +=(const Big & rightSide)
	  {
	  
	 Big returned;
   int extra = 0;

   for(int i = 0;
      i < chunks.size() && i < rightSide.chunks.size(); i++)
   {
   
   chunks.front() = i;
   rightSide.chunks.front()=i; 
     int num = chunks.front() + rightSide.chunks.front();

	  ListIterator <int> it;
   
               //it = (num % chunkSize) + extra;
	   
               it = chunks.begin();
               while (chunkSize-- > 0)
                  ++it;
      returned.chunks.insert(it,
         returned.chunks.size());
      //extra = num / chunkSize;
	  extra = num ;
   }

   if (extra != 0)
   {
   
   ListIterator <int> it;
   
               it = chunks.begin();
               while (chunkSize-- > 0)
                  ++it;
   
     // returned.chunks.insert(extra, returned.chunks.size());
	 
	 returned.chunks.insert(it, returned.chunks.size());
   }

   if(chunks.size() > rightSide.chunks.size())
   {
      for(int i = rightSide.chunks.size();
         i < chunks.size(); i+=1)
      {
	  chunks.front()=i;
	  
	  ListIterator <int> it;
   
               it = chunks.begin();
               while (chunkSize-- > 0)
                  ++it;
	  returned.chunks.insert(it,
            returned.chunks.size());
         
		 
		 //returned.chunks.insert(chunks.front(),
           // returned.chunks.size());
      }
   }
   else if(chunks.size() < rightSide.chunks.size())
   {
      for(int i = chunks.size();
            i < rightSide.chunks.size(); i+=1)
      {
	  
	  rightSide.chunks.front()=i;
	  
	  ListIterator <int> it;
   
               it = chunks.begin();
               while (chunkSize-- > 0)
                  ++it;
				  
				   returned.chunks.insert(it,
          returned.chunks.size());
	  
      //   returned.chunks.insert(rightSide.chunks.front(),
        //    returned.chunks.size());
      }
   }

   return returned;
	  
	  }
      
	  
	  friend ostream & operator << (ostream & out, const Big & big)
	  {
	  
	   for(int i = big.chunks.size() - 1;
      i >= 0; i -= 1)
   {
   big.chunks.front()=i;
      out << big.chunks.front() ;
   }
   return out;}
};


Big fib(int index)
{
   Big first = 0;
   Big second = 1;
   Big next = 0;  

for ( int c = 1 ; c < index ; c++ )
   {
      if ( c <= 1 )
         next = c;
      else
      {
         next = first += second;
         first = second;
         second = next;
		 
		
 
      }
      return next;
   }
 





}



/************************************************
 * FIBONACCI
 * The interactive function allowing the user to
 * display Fibonacci numbers
 ***********************************************/

 
 void fibonacci()
{
   // show the first several Fibonacci numbers
   int number;
   cout << "How many Fibonacci numbers would you like to see? ";
   cin  >> number;

   // your code to display the first <number> Fibonacci numbers

   
   
   int c, first = 0, second = 1, next;   
   
for ( c = 1 ; c < number+1 ; c++ )
   {
      if ( c <= 1 )
         next = c;
      else
      {
         next = first + second;
         first = second;
         second = next;
      }
  cout << "\t" <<next << endl;   
   }
   
  
   

   // prompt for a single large Fibonacci
   cout << "Which Fibonacci number would you like to display? ";
   cin  >> number;

   // your code to display the <number>th Fibonacci number
   
   //get number ex 100=354224848179261915075
   
cout << fib(number) << endl;
   
   
   

   
   
   //insert into list
   //separate with << operator by 3X7 & remove
   //output list
   
   cout << number << endl; 
   
   
}


