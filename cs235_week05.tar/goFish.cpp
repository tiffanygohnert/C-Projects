/***********************************************************************
* Program:
*    Assignment 01, Go Fish
*    Brother Helfrich, CS 235
* Author:
*    <your names here>
* Summary: 
*    This is all the functions necessary to play Go Fish!
*
*    Estimated:  0.0 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
#include "set.h"
#include "card.h"
#include "goFish.h"
#include <string>         // because testIterate() uses a Set of string
#include <vector>
using namespace std;

/**********************************************************************
 * GO FISH
 * The function which starts it all
 ***********************************************************************/
/******************************************
 * DISPLAY
 * Display the contents of the set
 *****************************************/
template <class T>
ostream & operator << (ostream & out, Set <T> & rhs)
{
   //out << "{ ";
   SetIterator <T> it;
   for (it = rhs.begin(); it != rhs.end(); ++it)
   {
	   out << *it;

   }

   //out << '}';
   return out;
}
 
 
 void goFish()
{
int round=1;  
int match=0; 
Set <string> hand; 
string card;

//instructions
cout << "We will play 5 rounds of Go Fish.  Guess the card in the hand" << endl; 

//insert 
vector <string> words; 
   string str; 

   ifstream fin("/home/cs235/week05/hand.txt"); // Open it up!
   //ifstream fin("C:/Users/jdavet/Desktop/hand.txt"); // Test locally
   while (fin >> str) 
   {
      words.push_back(str);
   }
   fin.close(); // Close that file!
   
   

   for (int i = 0; i < words.size(); ++i)
{
hand.insert(words.at(i));
}

  // make a copy of the set using the copy constructor
      Set <string> s2(hand);

//5 turns
//Prompt the user for a card
for (int i =1; i<6; i++)

{
//count rounds
cout << "round " << i <<": " ;
cin >> card; 


//Find card and empty
 SetIterator <string> itEmpty = hand.end();
         SetIterator <string> itFind = hand.find(card);
         if (itFind != itEmpty)
         {
            cout<< "\tYou got a match!"<< endl;
match++;
            hand.erase(itFind);
         }
         else
            cout<< "\tGo Fish!" << endl;



}



//return matches  
cout << "You have " << match << " matches!" <<endl; 

//return cards left by returning hand

	   
cout << "The remaining cards: "; /*<< hand << endl;*/
SetIterator <string> it;
for (it = hand.begin(); it != hand.end(); it++)
{
	if (it != hand.begin())
		cout << ", ";
	cout << *it;
}
cout << endl;

//return cards left by returning hand
//cout << "before: "  << s2 << endl; 

   return ;
}
