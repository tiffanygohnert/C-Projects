/***********************************************************************
* Header:
*    Go Fish
* Summary:
*    This will contain just the prototype for the goFish() function
* Author
*    <your names here>
************************************************************************/
#include <stdio.h>

#ifndef GO_FISH_H
#define GO_FISH_H


/**************************************************
 * GO FISH
 * Play the game of "Go Fish"
 *************************************************/
class Fish {

//initialize the deck

//shuffle

//deal

}; 
 
 
 void goFish();



#endif // GO_FISH_H

