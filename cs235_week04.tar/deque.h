#ifndef  DEQUE_H
#define DEQUE_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <stack>
using namespace std;


//stack class
template <class T>
class Deque
{

  public:

   //default constructor
  Deque():  Size(0),Capacity(0), vector(0x00000000), myFront(-1), myBack(-1){}

   //destructor
   ~Deque(){};
   // { if (Size) delete [] vector; }

   //non-default constructor Needed for test 1
   Deque(int capacity) throw (const char *);

   //copy constructor
   Deque(const Deque& rhs)throw (const char *);


   // assignment operator
   Deque & operator = (const Deque & rhs)throw (const char *)
   {
           try
           {  Deque temp = rhs;
              Capacity = temp.Capacity;
              vector = temp.vector;
              Size = temp.Size;
			  myFront = temp.myFront; 
			  myBack = temp.myBack; 
              return *this;
           }
           catch (std::bad_alloc)
           {
              throw "ERROR: Unable to allocate a new buffer for Deque";
           }

   }

   //empty()
   bool empty()const {return Size ==0;  }
   //clear()
   void clear(){Size =0; }

   //size()
   int size()const{return Size; }
   //capacity()
   int capacity()const {   return Capacity;}
   
   int clear() const {Size =0; return Size; }; 

   //push_back
   void push_back(const T & t) throw (const char *);
   void push_front(const T & t) throw (const char *);
   void pop_front() throw (const char *);
   void pop_back() throw (const char *);
    T front() throw (const char *); 
	 T back() throw (const char *); 
   

   // return an iterator to the beginning of the list
   //DequeIterator <T> begin() { return DequeIterator<T>(vector); }

   // return an iterator to the end of the list
   // DequeIterator <T> end() { return DequeIterator<T>(vector + Size);};



   // operators[]
   T & operator [](int& index) const throw(const char *)
   {
      if (Capacity < 0 || Capacity < Size)
         throw "ERROR: Invalid index\n";
      return vector[index];
   }

   T & operator [](int& index) throw(const char *)
   {
      if (Capacity < 0 || Capacity < Size)
         throw "ERROR: Invalid index\n";
      return vector[index];
   }




  private:

   int Size;
   T * vector;
   int Capacity;
   int myFront; 
   int myBack; 
  


};

/**********************************************
 * Deque : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Deque to "capacity"
 **********************************************/
template <class T>
Deque <T> :: Deque(int capacity) throw (const char *)
{
   assert(capacity >= 0);

   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->Capacity = this->Size = 0;
      this->vector = 0x00000000;
	  this->myFront= 0; 
	  this->myBack=1; 
      return;
   }

   // attempt to allocate
            try
            {
               vector = new T[capacity];

            }
            catch (std::bad_alloc)
            {
               //problem for test 1
               throw "ERROR: Unable to allocate buffer";


            }


            // copy over the stuff
            this->Capacity = capacity;
            this->Size = 0;
			this->myBack=0; 
			this->myFront=0; 

}

/*******************************************
 * Deque:: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Deque <T> :: Deque(const Deque <T> & rhs) throw (const char *)
{
   assert(rhs.Capacity >= 0);

   // do nothing if there is nothing to do
   if (rhs.Capacity == 0)
   {
      Capacity = Size = 0;
      vector = 0x00000000;
	  myFront=myBack=0; //sets capacity to 1; 
      return;
   }

   // attempt to allocate
          try
          {
             vector = new T[rhs.Capacity];
          }
          catch (std::bad_alloc)
          {
             throw "ERROR: Unable to allocate buffer";
          }

          // copy over the stuff
          assert(rhs.Size >= 0 && rhs.Size <= rhs.Capacity);
          this->Capacity = rhs.Capacity;
          this->Size = rhs.Size;
		  this->myFront = rhs.myFront; 
		  this->myBack = rhs.myBack;  
       // for (int i = myFront; i < Size; i++)
           // vector[i] = rhs.vector[i];
			//for (int i = 0; i < Size; i++)
         // vector[i] = rhs.vector[i];
		 
		 if ((myFront==0) && (myBack > myFront) && (myBack <= Capacity))
		  {
		  for(int i=myFront; i <myBack; i++)
		  vector[i]=rhs.vector[i];
		  if (myBack +1 <Capacity)
		  {
		  for (int i=myBack; i <Capacity; i++)
		  vector[i] = T(); 
		  }
		  }
		  
		  else if ((myFront>0) && (myBack >myFront)&& (myBack <=Capacity))
		  {
		  for (int i =myFront; i<myBack; i++)
		  vector[i]=rhs.vector[i]; 
		  if (myBack +1 < Capacity)
		  {
		  for (int i = myBack; i < Capacity; i++)
		  vector[i] = T(); 
		  for (int i=0; i<myFront; i++)
		  vector[i] = T();
		  }
		  }
		  
		   else if ((myFront>0) && (myBack <myFront)&& (myFront <=Capacity))
		  {
		  for (int i =myFront; i<Capacity; i++)
		  vector[i]=rhs.vector[i]; 
		  
		  for (int i = 0; i < myBack; i++)
		  vector[i] = rhs.vector[i]; 
		  for (int i=myBack; i<myFront; i++)
		  vector[i] = T();
		  }
		  
		  
		  else if (empty() && Capacity >0)
		  {
		  for (int i=0; i<Capacity; i++)
		  vector[i]=T(); 
		  }
		 
}

/***************************************************
 * Deque :: push_back
 * Insert an item on the end of the Deque
 **************************************************/
template <class T>
void Deque <T> :: push_back(const T & t) throw (const char *)
{

	if (this->Capacity == 0)
	{
		delete[] vector;
		Capacity = 1;
		this->vector = new T[Capacity];
		
		//this->vector=vector; 
		this->Capacity=1; 
		this->myFront=0; 
		this->myBack=1; 
		this->Size=0; 
	}

	/*if (Capacity == Size)
	{
		Capacity *= 2;
	}*/

if(myBack==Capacity)
	myBack=0; 
this->vector[myBack]=t; 
myBack++; 
Size++; 

	/*int newBack = (myBack + 1) % Capacity;
	if (newBack != myFront)
	{
		vector[myBack] = t;
		myBack = newBack;
	}
	else
	{
		cerr << "Queue full!";
		exit(1);
	}*/
	
	/*T * tempArray = new T[Capacity];
	tempArray[myBack] = t;
	for (int i = 0; i < this->Size - 1; i++)
	{
		tempArray[i] = this->vector[i];
	}
	delete[] this->vector;
	this->vector = tempArray;
	++myBack;
	++Size;*/

if (Capacity == Size)
{
	try
	{
		Capacity *= 2;
		T * tempArray = new T[Capacity];
		for (int i = 0; i < this->Size; i++)
		{
			tempArray[i] = this->vector[i];
		}
		delete[] this->vector;
		this->vector = tempArray;


	}
	catch (std::bad_alloc)
	{
		throw "ERROR: Unable to allocate a new buffer for Vector";
	}



	}

}

/***************************************************
* Deque :: push_front
* Insert an item on the end of the Deque
**************************************************/
template <class T>
void Deque <T> ::push_front(const T & t) throw (const char *)
{

	if (this->Capacity == 0)
	{
		delete[] vector;
		Capacity = 1;
		this->vector = new T[Capacity];

		//this->vector=vector; 
		this->Capacity = 1;
		this->myFront = 0;
		this->myBack = 1;
		this->Size = 0;
	}

	


	if (myBack == Capacity)
		myBack = 0;
	/*this->vector[myBack] = t;
	myBack++;
	Size++;*/

	T * tempArray = new T[Capacity];
	tempArray[0] = t;
	for (int i = 1; i < (this->Size + 1); i++)
	{
		tempArray[i] = this->vector[i - 1];
	}
	delete[] this->vector;
	this->vector = tempArray;
	this->myFront = 0;
	this->myBack++;
	this->Size++;
	
	if (Capacity == Size)
	{
		try
		{
			Capacity *= 2;
			T * tempArray = new T[Capacity];
			for (int i = 0; i < this->Size; i++)
			{
				tempArray[i] = this->vector[i];
			}
			delete[] this->vector;
			this->vector = tempArray;


		}
		catch (std::bad_alloc)
		{
			throw "ERROR: Unable to allocate a new buffer for Vector";
		}



	}

}


/***************************************************
 * Deque :: pop_front
 * Removes an item from the front of the deque
 **************************************************/
template <class T>
 void Deque <T> :: pop_front() throw (const char *)
{
	if (empty())
		throw "ERROR: unable to pop from the front of empty deque";
	else
	{
	myFront=(myFront + 1) % Capacity;
	//myFront++;
	Size--; 
	//vector[myFront];
	
	//if(myFront==Capacity)
	//{
	//myFront=0; //problem here. 
	//}
	//else
	//myFront++; 
	//Size--; 
	}
}

 /***************************************************
 * Deque :: pop_back
 * Removes an item from the back of the deque
 **************************************************/
 template <class T>
 void Deque <T> ::pop_back() throw (const char *)
 {
	 if (empty())
		 throw "ERROR: unable to pop from the back of empty deque";
	 else
	 {
		 //myFront=(myFront + 1) % Capacity;
		 //myBack--;
		 myBack = (myBack + 1) % Capacity;
		 Size--;
		 //vector[myFront];

		 //if(myFront==Capacity)
		 //{
		 //myFront=0; //problem here. 
		 //}
		 //else
		 //myFront++; 
		 //Size--; 
	 }
 }

/***************************************************
 * Deque :: front
 * Returns the item currently at the end of the stack
 **************************************************/
template <class T>
T Deque <T> :: front() throw (const char *)
{
	if (empty())
		throw "ERROR: unable to access data from an empty deque";
	return vector[myFront];   
}

/***************************************************
 * Deque :: back
 * Returns the item currently at the end of the stack
 **************************************************/
template <class T>
T Deque <T> :: back() throw (const char *)
{
	if (empty())
		throw "ERROR: unable to access data from an empty deque";
		//myBack = (myBack-1)%Capacity; 
	/*int newBack = myBack - 1;
	if (newBack < 0)
	{
		newBack = Size - 1;
	}*/
	return vector[Size - 1];   
}


 

#endif
