#ifndef  REQUEST_H
#define REQUEST_H
#include <cassert>
#include <iostream>
#include <fstream>
using namespace std;

class Request
{

  public:

   //default constructor
	  Request() : className(""), studentName(""), minutes(0), isUrgent(false) {};

   //destructor
   ~Request(){};
   // { if (Size) delete [] vector; }

   //non-default constructor Needed for test 1
   Request(string className, string studentName, int minutes, bool urgent)
   {
	   this->className = className;
	   this->studentName = studentName;
	   this->minutes = minutes;
	   this->isUrgent = urgent;
   }

   //copy constructor
   Request(const Request& rhs)
   {
	   this->className = rhs.className;
	   this->studentName = rhs.studentName;
	   this->minutes = rhs.minutes;
	   this->isUrgent = rhs.isUrgent;
   }


   // assignment operator
   /*Request & operator = (const Request & rhs)
   {
			Request temp = rhs;
			className = temp.className;
			studentName = temp.studentName;
			minutes = temp.minutes;
			return *this;
   }*/

   string getClassName()
   {
	   return className;
   }

   string getStudentName()
   {
	   return studentName;
   }

   int getMinutes()
   {
	   return minutes;
   }

   bool getIsUrgent()
   {
	   return isUrgent;
   }

   void setClassName(string newName)
   {
	   className = newName;
   }

   void setStudentName(string newName)
   {
	   studentName = newName;
   }

   void setMinutes(int newMinutes)
   {
	   minutes = newMinutes;
   }

   void setIsUrgent(bool newIsUrgent)
   {
	   isUrgent = newIsUrgent;
   }
   
  private:

   string className;
   string studentName;
   int minutes;
   bool isUrgent;


};

#endif
