/***********************************************************************
 * Implementation:
 *    NOW SERVING
 * Summary:
 *    This will contain the implementation for nowServing() as well as any
 *    other function or class implementations you may need
 * Author
 *    <your names here>
 **********************************************************************/

#include <iostream>     // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>       // for STRING
#include <cassert>      // for ASSERT
#include "nowServing.h" // for nowServing() prototype
#include "deque.h"      // for DEQUE
#include "request.h"    // for REQUEST
using namespace std;

bool hasCurrentStudent(string className, string studentName, int minutes)
{
	return (className != "" || studentName != "" || minutes != -1);
}

void display(bool urgent, string className, string studentName, int minutes)
{
	if (hasCurrentStudent(className, studentName, minutes))
	{
		urgent ? cout << "\tEmergency for " : cout << "\tCurrently serving ";
		cout << studentName << " for class " << className
			<< ". Time left: " << minutes << endl;
	}
	else
		return;
}

void advanceToNextMinute(int & totalMinutes, int & currentMinutes, bool & isUrgent, Deque <Request> & requests,
	string & currentClass, string & currentStudent)
{
	// get ready for next round
	totalMinutes++;
	currentMinutes--;

	// decrement minutes
	if (currentMinutes == 0)
	{
		// reset urgent if needed
		if (isUrgent)
			isUrgent = false;

		// if deque is empty, reset current student
		if (requests.empty())
		{
			currentClass = "";
			currentStudent = "";
			currentMinutes = -1;
		}

		// set current info to the Request in front of deque
		else
		{
			Request tempRequest = requests.front();
			currentClass = tempRequest.getClassName();
			currentStudent = tempRequest.getStudentName();
			currentMinutes = tempRequest.getMinutes();
			// update isUrgent if next student is urgent
			if (tempRequest.getIsUrgent())
				isUrgent = true;
			// pop front
			requests.pop_front();
		}
	}
}

/************************************************
 * NOW SERVING
 * The interactive function allowing the user to
 * handle help requests in the Linux lab
 ***********************************************/
void nowServing()
{
   // instructions
   cout << "Every prompt is one minute.  The following input is accepted:\n";
   cout << "\t<class> <name> <#minutes>    : a normal help request\n";
   cout << "\t!! <class> <name> <#minutes> : an emergency help request\n";
   cout << "\tnone                         : no new request this minute\n";
   cout << "\tfinished                     : end simulation\n";

   // your code here
   string text;

   // variables to store class, name, and minutes input
   // these values will be used to create a new Request object
   // which will be added to the Deque of Requests
   string className;
   string studentName;
   int minutes;
   bool isUrgent = false;

   // variables to store info of student currently helped
   // per instructions, current student shouldn't be on deque
   string currentClass = "";
   string currentStudent = "";
   int currentMinutes = -1;

   // totalMinutes is the number by the prompt that represents
   // how many minutes have passed since program initiation
   int totalMinutes = 0;
   Deque <Request> requests;
  
   do
	{
	
	
		//prompt user for input
		 cout << "<" << totalMinutes <<"> "; 
		 cin >> text; 
		 
		 // push urgent student to top of deque
		 if (text == "!!")
		 {
			 cin >> className >> studentName >> minutes;
			 // push request to front with isUrgent set to true
			 Request tempRequest(className, studentName, minutes, true);
				 requests.push_front(tempRequest);
				 display(isUrgent, currentClass, currentStudent, currentMinutes);
			 advanceToNextMinute(totalMinutes, currentMinutes, isUrgent, requests,
				 currentClass, currentStudent);
		 }

		 // end the program
		 else if (text == "finished")
		 {
			 break;
		 }

		 else if (text == "none")
		 {
			 // if there is a current student, display message,
			 // increment totalMinutes and decrement currentMinutes
			 if (hasCurrentStudent(currentClass, currentStudent, currentMinutes))
			 {
				 display(isUrgent, currentClass, currentStudent, currentMinutes);
				 advanceToNextMinute(totalMinutes, currentMinutes, isUrgent, requests,
					 currentClass, currentStudent);
			 }

			 // if no current student, just increment totalMinutes
			 else
			 {
				 totalMinutes++;
			 }
		 }

		 // if not urgent, finished, or none
		 else
		 {
			 // if decke is empty and no current student, make this student current
			 if (requests.empty() && !hasCurrentStudent(currentClass, currentStudent, currentMinutes))
			 {
				 currentClass = text;
				 cin >> currentStudent >> currentMinutes;
			 }
			 else 
			 {
				 className = text;
				 cin >> studentName >> minutes;
				 Request tempRequest(className, studentName, minutes, false);
				 requests.push_back(tempRequest);
			 }
			 display(isUrgent, currentClass, currentStudent, currentMinutes);
			 advanceToNextMinute(totalMinutes, currentMinutes, isUrgent, requests, currentClass, currentStudent);
		 }

	} while (text != "finished");

   cout << "End of simulation\n";
}


