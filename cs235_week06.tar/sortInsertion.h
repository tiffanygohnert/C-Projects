/***********************************************************************
 * Header:
 *    INSERTION SORT
 * Summary:
 *    This will contain just the prototype for insertionSortTest(). You may
 *    want to put other class definitions here as well.
 * Author
 *    Tiffany Gohnert, John Vehikite
 ************************************************************************/

#ifndef INSERTION_SORT_H
#define INSERTION_SORT_H
#include "node.h"


/***********************************************
 * INSERTION SORT
 * Sort the items in the array
 **********************************************/
template <class T>
void sortInsertion(T array[], int num)
{
//created linked-list
  Node <T> * n = NULL;
  //insert array into linked-list; 
  for (int i = 0; i < num; i++)
   { 
	insert(array[i], n);
	}
//sort the list

 Node <T> * temphead = n;
	T tempdata;
	T tempname;
	int counter = 0;
	while (temphead)
	{
		temphead = temphead->pNext;
		counter++;
	}
	temphead = n;
	
	for (int j=0; j<counter; j++)
	{
		while (temphead->pNext)  //iterate through list until pNext is null
		{
			if (temphead->data > temphead->pNext->data)
			{
				
				tempdata = temphead->data;
				temphead->data = temphead->pNext->data;
				temphead->pNext->data = tempdata;

				temphead = temphead->pNext;//increment node
			}
			else 
				temphead = temphead->pNext;//increment node
		}	
		temphead = n;//reset temphead
	}
	

//copy the elements from the linked-list back into the input array.
for (int i = 0; i < num; i++)
   {
   array[i]=n->data; 
n = n->pNext;
}
}





#endif // INSERTION_SORT_H

